package com.example.anotherdatabasetest;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class finderActivity extends AppCompatActivity {
    private DatabaseReference mDat;
    FirebaseDatabase Auth;
    final String ACTNAME = "finderActivity";

    public void OnCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.find_device);


        Intent intent = getIntent();
        String ID = intent.getStringExtra("UID");
        String Name = intent.getStringExtra("DisplayName");
        TextView textName = findViewById(R.id.greetingMessage);
        textName.setText(Name+"'s location");
        Button getLocation = findViewById(R.id.getLocation);
        getLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation(ID);
            }
        });
    }

    public void onResume() {

        super.onResume();




    }
    private void getLocation(String ID){
        mDat = FirebaseDatabase.getInstance().getReference("Users/"+ID+"/Location/Latitude");
        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                TextView Lat = findViewById(R.id.Latitude);
                Lat.setText(snapshot.getValue().toString());
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w(ACTNAME, "Failure: ", error.toException());
            }
        };

        mDat = FirebaseDatabase.getInstance().getReference("Users/"+ID+"/Location/Longitude");
        ValueEventListener anotherListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                TextView Long = findViewById(R.id.Longitude);
                Long.setText(snapshot.getValue().toString());
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w(ACTNAME, "Failure: ", error.toException());
            }
        };
        
    }
}
